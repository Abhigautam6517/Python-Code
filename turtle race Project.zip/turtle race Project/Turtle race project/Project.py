import turtle

from turtle import Turtle, Screen
import random

is_race_on = False
screen = Screen()
screen.setup(width=1000, height=600)
user_bet = screen.textinput(title="make Your bet", prompt="Which turtle win the race? Enter a colour:")
colors = ["red", "blue", "orange", "yellow", "green", "purple"]
y_position = [-50, -20, 10, 40, 70, 100]
all_turtle = []


for turtle_index in range(0, 6):
    tim = Turtle(shape = "turtle")
    tim.penup()
    tim.color(colors[turtle_index])
    tim.goto(x=-470, y=y_position[turtle_index])
    all_turtle.append(tim)

if user_bet:
    is_race_on = True

while is_race_on:
    for turtle in all_turtle:
        if turtle.xcor() > 470:
            is_race_on = False
            winning_color = turtle.pencolor()
            if winning_color == user_bet:
                print("You won")
            else:
                print("you lose")

        rand_distance = random.randint(0, 10)
        turtle.forward(rand_distance)

screen.exitonclick()